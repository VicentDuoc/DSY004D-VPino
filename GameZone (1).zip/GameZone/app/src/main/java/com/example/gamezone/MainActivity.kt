package com.example.gamezone
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import java.time.LocalDateTime
import java.time.Duration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.gamezone.ui.theme.GameZoneTheme


 class MainActivity : ComponentActivity() {

     enum class TipoUsuario {
         INFANTIL,
         SOCIO,
         EDUCACIONAL
     }
     enum class TipoConsola{
         Clasica,
         MOderna,
         VR,
     }
     enum class EstadoPuesto {
         LIBRE,
         EN_JUEGO,
         EN_PROCESO_REGISTRO,
         EN_REPARACION
     }



     open class Consola(
         val codigo: String,
         val marca: String,
         val modelo: String,
         val fechaIngreso: LocalDateTime,
         val tipoUsuario: TipoUsuario
     ) {

         open fun calcularCobro(minutos: Long): Double {
             return 0.0
         }

         open fun mostrarDetalle() {
             println("Código: $codigo")
             println("Marca: $marca")
             println("Modelo: $modelo")
             println("Fecha de ingreso: $fechaIngreso")
             println("Usuario: $tipoUsuario")
         }
     }

         open fun calcularCobro(minutos: Long): Double {
             return 0.0
         }

         open fun mostrarDetalle() {
             println("Código: $codigo")
             println("Marca: $marca")
             println("Modelo: $modelo")
             println("Fecha de ingreso: $fechaIngreso")
             println("Usuario: $tipoUsuario")
         }
     }
    open class ConsolaVR(val puesto :Int,val Estado:String, val libre:String,  val Turno : String,)
    }
class ConsolaModerna(
    codigo: String,
    marca: String,
    modelo: String,
    fechaIngreso: LocalDateTime,
    tipoUsuario: TipoUsuario,
) : Consola(
    codigo,
    marca,
    modelo,
    fechaIngreso,
    tipoUsuario
) {


    override fun calcularCobro(minutos: Long): Double {

        if (minutos < 20) {
            return 0.0
        }

        val tarifaPorMinuto = 1500.0 / 60

        return minutos * tarifaPorMinuto
    }

    override fun mostrarDetalle() {

        super.mostrarDetalle()

        println("Tipo: Consola Moderna")
        println("Tarifa base: $1500/hora")
    }
    if (minutos < 20) {
        return 0.0
    }class ConsolaVR(
        codigo: String,
        marca: String,
        modelo: String,
        fechaIngreso: LocalDateTime,
        tipoUsuario: TipoUsuario,
        val accesoriosPremium: Boolean
    ) : Consola(
        codigo,
        marca,
        modelo,
        fechaIngreso,
        tipoUsuario
    ) {

        override fun calcularCobro(minutos: Long): Double {

            val tarifaPorMinuto = 3000.0 / 60

            var monto = minutos * tarifaPorMinuto

            if (accesoriosPremium) {
                monto *= 1.30
            }

            return monto
        }

        override fun mostrarDetalle() {

            super.mostrarDetalle()

            println("Tipo: Consola VR")
            println("Tarifa base: $3000/hora")

            if (accesoriosPremium) {
                println("Accesorios premium: Sí")
            } else {
                println("Accesorios premium: No")

            }
        }
    }
}



@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    GameZoneTheme {
        Greeting("Android")
    }
}