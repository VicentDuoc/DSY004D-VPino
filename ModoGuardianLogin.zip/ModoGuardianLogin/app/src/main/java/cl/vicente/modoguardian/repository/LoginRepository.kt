package cl.vicente.modoguardian.repository

import cl.vicente.modoguardian.model.User
import cl.vicente.modoguardian.model.UserRole
import kotlinx.coroutines.delay

class LoginRepository {

    private val testUsers = listOf(
        User("admin@guardian.test", "123456", UserRole.ADMIN),
        User("supervisor@guardian.test", "123456", UserRole.SUPERVISOR),
        User("operador@guardian.test", "123456", UserRole.OPERADOR)
    )

    // Datos sintéticos exigidos por el caso Modo Guardián.
    suspend fun login(email: String, password: String): Result<User> {
        delay(700)

        val user = testUsers.firstOrNull {
            it.email.equals(email.trim(), ignoreCase = true) &&
                it.password == password
        }

        return if (user != null) {
            Result.success(user)
        } else {
            Result.failure(IllegalArgumentException("Credenciales inválidas"))
        }
    }
}
