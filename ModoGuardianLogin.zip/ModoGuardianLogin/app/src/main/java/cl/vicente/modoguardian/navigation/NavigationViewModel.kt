package cl.vicente.modoguardian.navigation

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

class NavigationViewModel : ViewModel() {

    private val _events = MutableSharedFlow<NavigationEvent>()
    val events = _events.asSharedFlow()

    suspend fun navigateTo(route: String) {
        _events.emit(NavigationEvent.NavigateTo(route))
    }

    suspend fun navigateBack() {
        _events.emit(NavigationEvent.NavigateBack)
    }
}
