package cl.vicente.modoguardian.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cl.vicente.modoguardian.model.LoginErrores
import cl.vicente.modoguardian.model.LoginUiState
import cl.vicente.modoguardian.model.UserRole
import cl.vicente.modoguardian.repository.LoginRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LoginViewModel(
    private val repository: LoginRepository = LoginRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    fun onEmailChange(value: String) {
        _uiState.value = _uiState.value.copy(
            email = value,
            emailError = null,
            generalError = null
        )
    }

    fun onPasswordChange(value: String) {
        _uiState.value = _uiState.value.copy(
            password = value,
            passwordError = null,
            generalError = null
        )
    }

    fun validarFormulario(): Boolean {
        val current = _uiState.value
        var valid = true
        var emailError: String? = null
        var passwordError: String? = null

        if (current.email.isBlank()) {
            emailError = LoginErrores.EMAIL_REQUIRED
            valid = false
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(current.email).matches()) {
            emailError = LoginErrores.EMAIL_INVALID
            valid = false
        }

        if (current.password.isBlank()) {
            passwordError = LoginErrores.PASSWORD_REQUIRED
            valid = false
        } else if (current.password.length < 6) {
            passwordError = LoginErrores.PASSWORD_SHORT
            valid = false
        }

        _uiState.value = current.copy(
            emailError = emailError,
            passwordError = passwordError
        )

        return valid
    }

    fun login(onSuccess: (UserRole) -> Unit) {
        if (!validarFormulario()) return

        val current = _uiState.value

        viewModelScope.launch {
            _uiState.value = current.copy(
                isLoading = true,
                generalError = null
            )

            repository.login(current.email, current.password)
                .onSuccess { user ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        role = user.role
                    )
                    onSuccess(user.role)
                }
                .onFailure {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        generalError = LoginErrores.INVALID_CREDENTIALS
                    )
                }
        }
    }

    fun clearSession() {
        _uiState.value = LoginUiState()
    }
}
