package cl.vicente.modoguardian

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import cl.vicente.modoguardian.navigation.NavigationEvent
import cl.vicente.modoguardian.navigation.NavigationViewModel
import cl.vicente.modoguardian.ui.HomeScreen
import cl.vicente.modoguardian.ui.LoginScreen
import cl.vicente.modoguardian.ui.theme.ModoGuardianTheme
import cl.vicente.modoguardian.viewmodel.LoginViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ModoGuardianTheme()

            val navController = rememberNavController()
            val navigationViewModel: NavigationViewModel = viewModel()
            val loginViewModel: LoginViewModel = viewModel()

            LaunchedEffect(Unit) {
                navigationViewModel.events.collect { event ->
                    when (event) {
                        is NavigationEvent.NavigateTo -> {
                            navController.navigate(event.route) {
                                launchSingleTop = true
                            }
                        }

                        NavigationEvent.NavigateBack -> {
                            navController.popBackStack()
                        }
                    }
                }
            }

            NavHost(
                navController = navController,
                startDestination = "login"
            ) {

                composable("login") {
                    LoginScreen(
                        viewModel = loginViewModel,
                        navigationViewModel = navigationViewModel
                    )
                }

                composable("home_admin") {
                    HomeScreen(
                        loginViewModel = loginViewModel,
                        navigationViewModel = navigationViewModel
                    )
                }

                composable("home_supervisor") {
                    HomeScreen(
                        loginViewModel = loginViewModel,
                        navigationViewModel = navigationViewModel
                    )
                }

                composable("home_operador") {
                    HomeScreen(
                        loginViewModel = loginViewModel,
                        navigationViewModel = navigationViewModel
                    )
                }
            }
        }
    }
}