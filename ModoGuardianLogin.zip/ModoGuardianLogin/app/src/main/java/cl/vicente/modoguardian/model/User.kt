package cl.vicente.modoguardian.model

data class User(
    val email: String,
    val password: String,
    val role: UserRole
)
