package cl.vicente.modoguardian.ui.utils

import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.activity.ComponentActivity

@OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
fun ComponentActivity.getWindowWidthSizeClass(): WindowWidthSizeClass =
    calculateWindowSizeClass(this).widthSizeClass
