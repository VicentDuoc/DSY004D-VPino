package cl.vicente.modoguardian.model

object LoginErrores {
    const val EMAIL_REQUIRED = "Ingresa tu correo."
    const val EMAIL_INVALID = "Ingresa un correo válido."
    const val PASSWORD_REQUIRED = "Ingresa tu contraseña."
    const val PASSWORD_SHORT = "La contraseña debe tener al menos 6 caracteres."
    const val INVALID_CREDENTIALS = "Correo o contraseña incorrectos."
    const val CONNECTION_ERROR = "No fue posible completar la operación."
}
