package cl.vicente.modoguardian.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import cl.vicente.modoguardian.navigation.NavigationViewModel
import cl.vicente.modoguardian.viewmodel.LoginViewModel
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    loginViewModel: LoginViewModel,
    navigationViewModel: NavigationViewModel
) {
    // El Home observa el mismo LoginViewModel solicitado por la pauta.
    val state by loginViewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Acceso concedido")
            Text("Rol: ${state.role?.displayName ?: "No definido"}")

            Button(
                onClick = {
                    loginViewModel.clearSession()
                    scope.launch {
                        navigationViewModel.navigateTo("login")
                    }
                }
            ) {
                Text("Cerrar sesión")
            }
        }
    }
}
