package cl.vicente.modoguardian.model

data class LoginUiState(
    val email: String = "",
    val password: String = "",
    val isLoading: Boolean = false,
    val role: UserRole? = null,
    val emailError: String? = null,
    val passwordError: String? = null,
    val generalError: String? = null
) {
    val isLoginEnabled: Boolean
        get() = email.isNotBlank() && password.isNotBlank() && !isLoading
}

enum class UserRole(val displayName: String, val route: String) {
    ADMIN("Administrador", "home_admin"),
    SUPERVISOR("Supervisor", "home_supervisor"),
    OPERADOR("Operador", "home_operador")
}
