package cl.vicente.modoguardian.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val GuardianColors = lightColorScheme()

@Composable
fun ModoGuardianTheme(content: @Composable () -> Unit = {}) {
    MaterialTheme(
        colorScheme = GuardianColors,
        content = content
    )
}
