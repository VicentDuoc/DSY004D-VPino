package cl.vicente.modoguardian.repository

import android.content.Context
import cl.vicente.modoguardian.model.UserRole

class SessionRepository(context: Context) {

    private val preferences =
        context.getSharedPreferences("guardian_session", Context.MODE_PRIVATE)

    fun saveRole(role: UserRole) {
        preferences.edit().putString(KEY_ROLE, role.name).apply()
    }

    fun getRole(): UserRole? =
        preferences.getString(KEY_ROLE, null)?.let {
            runCatching { UserRole.valueOf(it) }.getOrNull()
        }

    fun clear() {
        preferences.edit().clear().apply()
    }

    companion object {
        private const val KEY_ROLE = "role"
    }
}
