package cl.vicente.modoguardian.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import cl.vicente.modoguardian.R
import cl.vicente.modoguardian.navigation.NavigationViewModel
import cl.vicente.modoguardian.viewmodel.LoginViewModel

@Composable
fun LoginScreen(
    viewModel: LoginViewModel,
    navigationViewModel: NavigationViewModel
) {
    val state by viewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()

    Scaffold { padding ->
        ResponsiveLoginContent(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            state = state,
            onEmailChange = viewModel::onEmailChange,
            onPasswordChange = viewModel::onPasswordChange,
            onLogin = {
                viewModel.login { role ->
                    scope.launch {
                        navigationViewModel.navigateTo(role.route)
                    }
                }
            }
        )
    }
}

@Composable
private fun ResponsiveLoginContent(
    modifier: Modifier,
    state: cl.vicente.modoguardian.model.LoginUiState,
    onEmailChange: (String) -> Unit,
    onPasswordChange: (String) -> Unit,
    onLogin: () -> Unit
) {
    Box(modifier = modifier.padding(24.dp), contentAlignment = Alignment.Center) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_guardian_logo),
                    contentDescription = "Logo Modo Guardián"
                )

                Spacer(Modifier.height(12.dp))

                Text(
                    text = "Modo Guardián",
                    style = MaterialTheme.typography.headlineMedium
                )

                Text(
                    text = "Inicio de sesión",
                    style = MaterialTheme.typography.bodyLarge
                )

                Spacer(Modifier.height(24.dp))

                OutlinedTextField(
                    value = state.email,
                    onValueChange = onEmailChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Correo") },
                    singleLine = true,
                    isError = state.emailError != null,
                    supportingText = {
                        state.emailError?.let { Text(it) }
                    }
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = state.password,
                    onValueChange = onPasswordChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Contraseña") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    isError = state.passwordError != null,
                    supportingText = {
                        state.passwordError?.let { Text(it) }
                    }
                )

                state.generalError?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(Modifier.height(20.dp))

                Button(
                    onClick = onLogin,
                    enabled = state.isLoginEnabled,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (state.isLoading) {
                        CircularProgressIndicator()
                    } else {
                        Text("Ingresar")
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, widthDp = 360, heightDp = 740)
@Composable
private fun LoginCompactPreview() {
    ResponsiveLoginContent(
        modifier = Modifier.fillMaxSize(),
        state = cl.vicente.modoguardian.model.LoginUiState(),
        onEmailChange = {},
        onPasswordChange = {},
        onLogin = {}
    )
}

@Preview(showBackground = true, widthDp = 840, heightDp = 600)
@Composable
private fun LoginExpandedPreview() {
    ResponsiveLoginContent(
        modifier = Modifier.fillMaxSize(),
        state = cl.vicente.modoguardian.model.LoginUiState(),
        onEmailChange = {},
        onPasswordChange = {},
        onLogin = {}
    )
}
